# Insect Resonance Tool

A web-based experimental interface to test resonance effects on insects using audio and/or light.

## Usage

1. Click 'Activate System' to unlock the AudioContext.
2. Select a mode (Sound, Flash, or Both).
3. Use the manual frequency slider or run the full sequence.

## Deployment

Upload all files to a GitHub repository and enable GitHub Pages.

GitHub Pages URL: `https://<your-username>.github.io/<repo-name>/`
